<?php


namespace Modules\Page;


class Hook
{
    const FORM_AFTER_HEADER_STYLE = 'page_form_after_header_style';
    const PAGE_BEFORE_SAVING = 'page_before_saving';
}
